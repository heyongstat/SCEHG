// [[Rcpp::depends(RcppEigen)]]
#include<RcppEigen.h>
#include <Rcpp.h>
#define min(a,b) ((a) < (b) ? (a) : (b))
using namespace Eigen;
using namespace Rcpp;

//==============================================================================================//
//======================================CCD to Solve Lasso======================================//

//----------------------------------------------------------------**
//***----------------Soft Thresholding Operator-------------------**

double Soft(double x, double lambda)
{
	if(x<(-lambda))
	{
		return x+lambda;
	}
	else if(x>lambda)
	{
		return x-lambda;
	}
	else
	{
		return 0;
	}
}

//----------------------------------------------------------------**
//***----------------Stopping Criteria for Lasso------------------**

bool SC_LASSO(VectorXd beta_hat, VectorXd beta_init, double eps)
{
	if(((beta_init-beta_hat).norm()/beta_init.norm())<eps) 
	{
		return false;
	}
	else
    {
    	return true;
    }
}

//----------------------------------------------------------------**
//***-------------Cyclic Coordinate Descent Method----------------**

VectorXd CCD_Lasso(MatrixXd x, VectorXd y, double lambda, double eps=0.00001, int maxiter=100)
{
	int n=x.rows();
	int p=x.cols();

	int count=1;
	VectorXd beta_init;
	VectorXd beta_hat;
	beta_init.setOnes(p);

    double standard;
    VectorXd r;
    double ip_rx;

    bool con=true;
    while(con)
	{
		beta_hat=beta_init;
		for(int j=0;j<p;j=j+1)
		{
			standard=pow(x.col(j).norm(),2);
			r=y-x*beta_hat+x.col(j)*beta_hat(j);
            ip_rx=r.dot(x.col(j))/standard;
            beta_hat(j)=Soft(ip_rx,(lambda*n/standard));
		}

		con=SC_LASSO(beta_hat,beta_init, eps);
	    if((con==true) && (count<=maxiter))
	    {
	    	beta_init=beta_hat;
		    count=count+1;          
	    }
	    else
	    {
	    	return beta_hat;
	    }
	}
}

//==============================================================================================//
//==========================================End CCD=============================================//



//==============================================================================================//
//==========================================DC-ADMM=============================================//

//----------------------------------------------------------------**
//***--------------Clustering Based on theta.hat------------------**

VectorXi Group(int n, VectorXi n_vec, MatrixXd theta){
   VectorXi G;
   G.setZero(n);
   G(0)=1;
   int G_num=1;  
   for(int i=0;i<(n-1);i++){
    for(int j=i+1;j<n;j++){
        if(theta.row(n_vec.segment(0,i+1).sum()+j-i-1).cwiseAbs().sum()==0){
            if(G(j)==0){
                if(G(i)!=0){
                    G(j)=G(i);
                }
                else{
                    G_num++;
                    G(i)=G_num;
                    G(j)=G(i);
                }
            }
            else{
                if(G(i)==0){
                    G(i)=G(j);
                }
                else{
                    if(G(i)<G(j)){
                        int G_large=G(j);
                        for(int tem_i=0;tem_i<n;tem_i++){
                            if(G(tem_i)==G_large){
                                G(tem_i)=G(i);
                            }
                        }
                    }
                    if(G(i)>G(j)){
                        int G_large=G(i);
                        for(int tem_i=0;tem_i<n;tem_i++){
                            if(G(tem_i)==G_large){
                                G(tem_i)=G(j);
                            }
                        }
                    }
                }
            }
        }
    }
   }

   for(int i=0;i<n;i++){
        if(G(i)==0){
            G_num++;
            G(i)=G_num;
        }
    }
   return G;
}

//----------------------------------------------------------------**
//***-------------Loss Functoin without constraint----------------**

double Score(int n_sum, MatrixXd mu, MatrixXd theta, MatrixXd x, double tau, double lambda1, double lambda2)
{
	double S=0.5*pow((x-mu).norm(),2)+lambda1*mu.cwiseAbs().sum();
    for(int i=0;i<(n_sum);i=i+1)
	{
		S=S+min(theta.row(i).norm(),tau)*lambda2;
	}

	return S;
}

//----------------------------------------------------------------**
//***----------------Stopping Criteria for Lasso------------------**

bool SC_mu(MatrixXd beta_hat, MatrixXd beta_init, double eps)
{
	double beta_init_l2=beta_init.norm();
	if(beta_init_l2==0)
	{
		return (beta_init-beta_hat).norm()>eps;
	}
	else
	{
		return ((beta_init-beta_hat).norm()/beta_init_l2)>eps;
	}
}

//----------------------------------------------------------------**
//***--------------------Update mu by Lasso-----------------------**

MatrixXd AD1(int n, int p, VectorXi n_vec, MatrixXd E, MatrixXd x, double rho, double lambda1, MatrixXd theta_init, MatrixXd mu_init, MatrixXd v_init, double eps)
{
	MatrixXd mu_update;
	mu_update.resize(n,p);

	MatrixXd z_star;
	z_star.resize(n*p,p);

	VectorXd y_star;
	y_star.resize(n*p);

	VectorXd y_star1;
	y_star1.resize((n-1)*p);

	for(int i=0;i<n;i=i+1)
	{
		for(int j=0;j<n;j=j+1)
		{
			if(j<i)
			{
				z_star.block(j*p,0,p,p)=-E;
				y_star1.segment(p*j,p)=theta_init.row(n_vec.segment(0,j+1).sum()+i-j-1)-mu_update.row(j)+v_init.row(n_vec.segment(0,j+1).sum()+i-j-1);
			} else if(j==i) 
			{
				z_star.block(j*p,0,p,p)=-E;
			} else
			{
				z_star.block(j*p,0,p,p)=E;
				y_star1.segment(p*(j-1),p)=theta_init.row(n_vec.segment(0,i+1).sum()+j-i-1)+mu_init.row(j)+v_init.row(n_vec.segment(0,i+1).sum()+j-i-1);
			}
		}

		z_star.block(0,0,p,p)=E/pow(rho,0.5);
		y_star.segment(0,p)=x.row(i)/pow(rho,0.5);
		y_star.segment(p,(n-1)*p)=y_star1;

		z_star=z_star*pow(rho/2,0.5);
	    y_star=y_star*pow(rho/2,0.5);

	    mu_update.row(i)=CCD_Lasso(z_star,y_star,lambda1,eps);
	}
	return mu_update;
}

//----------------------------------------------------------------**
//***-----------Update theta by Block Soft Thresholding-----------**

MatrixXd  AD2(int n, int p, int n_sum, double rho, double tau, double lambda2, MatrixXd theta_m, MatrixXd mu_update, MatrixXd v_init)
{
	MatrixXd theta_update;
	theta_update.resize(n_sum,p);
	
	MatrixXd muv;
	muv.resize(n_sum,p);

	int muv_index=0;
	for(int i=0;i<(n-1);i=i+1)
	{
		for(int j=i+1;j<n;j=j+1)
		{
			muv.row(muv_index)=(mu_update.row(i)-mu_update.row(j))-v_init.row(muv_index);
			muv_index=muv_index+1;
		}
	}

	double muv_l2;

	for(int i=0;i<n_sum;i=i+1)
	{
		if(theta_m.row(i).norm()>=tau)
		{
			theta_update.row(i)=muv.row(i);
		}
		else 
		{
			muv_l2=muv.row(i).norm();
			if(muv_l2==0)
			{
				theta_update.row(i)=muv.row(i);
			}
			else
			{
				theta_update.row(i)=(1-lambda2/rho/muv_l2)*(muv_l2>=(lambda2/rho))*muv.row(i);
			}
		}
	}

	return theta_update;
}

//----------------------------------------------------------------**
//***-------------------------ADMM Method-------------------------**

List ADMM(int n, int p, VectorXi n_vec, int n_sum, MatrixXd E, MatrixXd x, double rho, double tau, double lambda1, double lambda2, MatrixXd mu_init, MatrixXd theta_init, MatrixXd theta_m, MatrixXd v_init, double eps, int ADMM_maxiter)
{
	List R;
	bool con=true;
	MatrixXd mu_update;
	MatrixXd theta_update;
	MatrixXd v_update;
	v_update.resize(n_sum,p);
	int ADMM_count=0;

	while(con)
	{
		mu_update=AD1(n,p,n_vec,E,x,rho,lambda1,theta_init,mu_init,v_init,eps);
		theta_update=AD2(n,p,n_sum,rho,tau,lambda2,theta_m,mu_update,v_init);
		
		int v_index=0;
		for(int i=0;i<(n-1);i=i+1)
		{
			for(int j=i+1;j<n;j=j+1)
			{
				v_update.row(v_index)=v_init.row(v_index)+theta_update.row(v_index)-mu_update.row(i)+mu_update.row(j);
				v_index=v_index+1;
			}
		}

		con=SC_mu(mu_update,mu_init,eps);
		
		if(ADMM_count<3)
		{
			con=true;
		}
		if(con)
		{
			mu_init=mu_update;
			theta_init=theta_update;
			v_init=v_update;
		}
		else
		{
			R["mu_update"]=mu_update;
			R["theta_update"]=theta_update;
			R["v_update"]=v_update;
			R["ADMM_count"]=ADMM_count;
			return R;

		}

		ADMM_count=ADMM_count+1;
		if(ADMM_count>=ADMM_maxiter)
		{
			R["mu_update"]=mu_update;
			R["theta_update"]=theta_update;
			R["v_update"]=v_update;
			R["ADMM_count"]=ADMM_count;
			return R;
		}
	}
}

//----------------------------------------------------------------**
//***-------------------- DCupper iteration-----------------------**

//[[Rcpp::export]]
List SPRclust(Eigen::MatrixXd x, double tau, double rho, double lambda1, double lambda2, double eps=0.00001, int ADMM_maxiter=3000)
{

	int n=x.rows();
	int p=x.cols();

	MatrixXd E=MatrixXd::Identity(p,p);

	int n_sum=n*(n-1)/2;
	VectorXi n_vec;
	n_vec.resize(n);
	n_vec(0)=0;
	for(int i=1;i<n;i=i+1)
	{
		n_vec(i)=n-i;
	}

	MatrixXd mu_zero=x;
	MatrixXd theta_zero;
	theta_zero.resize(n_sum,p);
	MatrixXd v_zero;
	v_zero.resize(n_sum,p);
	v_zero.fill(0);

	int theta_zero_index=0;
	for(int i=0;i<(n-1);i=i+1)
	{
		for(int j=i+1;j<n;j=j+1)
		{
			theta_zero.row(theta_zero_index)=x.row(i)-x.row(j);
			theta_zero_index=theta_zero_index+1;
		}	
	}

	double S0=Score(n_sum,mu_zero,theta_zero,x,tau,lambda1,lambda2);
	List result0;
	result0["mu_update"]=mu_zero;
	result0["theta_update"]=theta_zero;
	result0["v_update"]=v_zero;

	bool DC_con=true;
	int DC_count=0;
	NumericVector ADMM_count_vec;
	NumericVector S;
	S.push_back(S0);
	MatrixXd theta_m=theta_zero;
	List result;
	double S1;
	while(DC_con)
	{
		DC_count=DC_count+1;
		result=ADMM(n,p,n_vec,n_sum,E,x,rho,tau,lambda1,lambda2,mu_zero,theta_zero,theta_m,v_zero,eps,ADMM_maxiter);
        ADMM_count_vec.push_back(result["ADMM_count"]);
        S1=Score(n_sum,result["mu_update"],result["theta_update"],x,tau,lambda1,lambda2);
        S.push_back(S1);
        if(DC_count<=1)
        {
        	S0=S1;
        	theta_m=result["theta_update"];
        	result0=result;
        }
        else
        {
        	if(S1<S0)
        	{
        		S0=S1;
        		theta_m=result["theta_update"];
        		result0=result;
        	}
        	else
        	{
        		result0["Group"]=Group(n,n_vec,result0["theta_update"]);
        		result0["DC_count"]=DC_count;
        		result0["ADMM_count"]=ADMM_count_vec;
        		result0["S"]=S;
        		return result0;
        	}
        }	
	}
}


//==============================================================================================//
//===========================================End DC=============================================//
